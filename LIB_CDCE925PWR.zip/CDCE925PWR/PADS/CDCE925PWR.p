*PADS-LIBRARY-PART-TYPES-V9*

CDCE925PWR SOP65P640X120-16N I ANA 7 1 0 0 0
TIMESTAMP 2026.05.15.21.44.01
"Mouser Part Number" 595-CDCE925PWR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/CDCE925PWR?qs=EkVHNy6q9HMXfYCRBDuXDg%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" CDCE925PWR
"Description" Programmable 2-PLL VCXO Clock Synthesizer with 2.5-V or 3.3-V LVCMOS Outputs
"Datasheet Link" http://www.ti.com/lit/gpn/CDCE925
"Geometry.Height" 1.2mm
GATE 1 16 0
CDCE925PWR
1 0 U XIN/CLK
2 0 U S0
3 0 U VDD
4 0 U VCTRL
5 0 U GND_1
6 0 U VDDOUT_1
7 0 U Y4
8 0 U Y5
16 0 U XOUT
15 0 U SDA/S1
14 0 U SCL/S2
13 0 U Y1
12 0 U GND_2
11 0 U Y2
10 0 U Y3
9 0 U VDDOUT_2

*END*
*REMARK* SamacSys ECAD Model
673325/1653454/2.50/16/3/Integrated Circuit
